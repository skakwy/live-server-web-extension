# Changelog
| Version | Date | Changelog |
|---|---|---|
| 1.3.0|18.05.18|  &mdash; ***[Fixed]*** Reload all browser tabs [[#16](https://github.com/ritwickdey/live-server-web-extension/issues/16)] |
| 1.2.0|17.05.18|  &mdash; Serious Bug Fixed |
| 1.1.0|17.05.18|  &mdash; This extension was broken with Live Server v4.0.0 update. [[#127](https://github.com/ritwickdey/vscode-live-server/issues/127)] <br> &mdash; Popup window UI updated <br> &mdash;  Docs updated. |
| 1.0.0 | 26.10.17 | &mdash; ***[New Feature]*** No need to setup proxy. There is now a way to setup - that is pretty easy & straight-forward. <br><br>&mdash; ***[Enhancement]*** Pop-up window is redesigned. <br><br>&mdash; ***[Bug Fixes]*** Small bug fixes related to the turn on/off switch. <br><br>&mdash; No BETA. General Release. |
0.0.1 | 22.10.17  | Initial Release under BETA |
